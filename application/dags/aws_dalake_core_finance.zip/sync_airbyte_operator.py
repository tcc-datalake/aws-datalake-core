import requests
import json
from airflow.models import BaseOperator
from airflow.utils.decorators import apply_defaults
from airflow.hooks.base_hook import BaseHook
from airflow.providers.airbyte.hooks.airbyte import AirbyteHook
from airflow.exceptions import AirflowException



class CogAirbyteTriggerSyncOperator(BaseOperator):

    @apply_defaults
    def __init__(
        self,
        airbyte_connection_name,
        airflow_connection="airbyte_default",
        timeout=3600,
        api_version="v1",
        wait_seconds=3,
        asynchronous=False,
        *args,
        **kwargs
    ):
        super().__init__(**kwargs)
        
        self.airbyte_connection_name = airbyte_connection_name
        self.airflow_connection = airflow_connection
        airbyte_conn = BaseHook.get_connection(self.airflow_connection)
        self.url = airbyte_conn.host
        self.port = airbyte_conn.port
        self.auth = (airbyte_conn.login, airbyte_conn.password)

        self.timeout = timeout
        self.api_version = api_version
        self.wait_seconds = wait_seconds
        self.asynchronous = asynchronous

    
    def get_connection_id(self):
        """
        Get connection ID from Airbyte.

        Args:
            connection_name: Airbyte connection name

        Returns:
            str: Airbyte connection ID.
        """

        url_workspace = f'{self.url}:{self.port}/api/v1/workspaces/list'
        url_connections = f'{self.url}:{self.port}/api/v1/web_backend/connections/list'
        headers = {'Content-Type': 'application/json'}
        workspacesReq = requests.post(url_workspace, auth=self.auth)
        assert workspacesReq.status_code == 200, f"Request error: status {workspacesReq.status_code}"
        workspaces = json.loads(workspacesReq.text)["workspaces"]
        workspaceList = []
        for i in range(len(workspaces)):
            workspaceList.append(str(workspaces[i]).replace("'",'"').replace("True", "true").replace("False","false"))
        connectionsList = []
        for workspace in workspaceList:
            connectionsReq = requests.post(url_connections, auth=self.auth, headers=headers, data=workspace)
            assert connectionsReq.status_code == 200, f"Request error: status {connectionsReq.status_code}"
            connections = json.loads(connectionsReq.text)['connections']
            for i in range(len(connections)):
                conn_name = json.loads(connectionsReq.text)['connections'][i]['name']
                if self.airbyte_connection_name == conn_name:
                    return json.loads(connectionsReq.text)['connections'][i]['connectionId']
        raise AirflowException("Airbyte connection name does not exists")


    def execute(self, context):
        """Create Airbyte Job and wait to finish"""
        conn_id = self.get_connection_id()

        self.hook = AirbyteHook(airbyte_conn_id=self.airflow_connection, api_version=self.api_version)
        job_object = self.hook.submit_sync_connection(connection_id=conn_id)
        self.job_id = job_object.json()["job"]["id"]

        self.log.info("Job %s was submitted to Airbyte Server", self.job_id)
        if not self.asynchronous:
            self.log.info("Waiting for job %s to complete", self.job_id)
            self.hook.wait_for_job(job_id=self.job_id, wait_seconds=self.wait_seconds, timeout=self.timeout)
            self.log.info("Job %s completed successfully", self.job_id)

        return self.job_id


    def on_kill(self):
        """Cancel the job if task is cancelled"""
        if self.job_id:
            self.log.info("on_kill: cancel the airbyte Job %s", self.job_id)
            self.hook.cancel_job(self.job_id)

