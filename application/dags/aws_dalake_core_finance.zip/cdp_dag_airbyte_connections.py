from airflow import DAG
from airflow.models import Variable
from sync_airbyte_operator import CogAirbyteTriggerSyncOperator
from airflow.providers.amazon.aws.operators.glue import GlueJobOperator
from airflow.operators.dummy_operator import DummyOperator

from datetime import datetime, timedelta

def getGlueJobArguments(glue_job_name, glue_asset_bucket):
    glue_job_arguments = {
    "--enable-metrics":"true",
    "--enable-spark-ui":"true",
    "--spark-event-logs-path":f"s3://{glue_asset_bucket}/sparkHistoryLogs/",    
    "--enable-job-insights": "true",
    "--enable-glue-datacatalog": "true",
    "--enable-continuous-cloudwatch-log": "true",
    "--job-bookmark-option": "job-bookmark-disable",
    "--job-language": "python",
    "--TempDir": f"s3://{glue_asset_bucket}//temporary/",
    "--JOB_NAME": glue_job_name}
    return glue_job_arguments



# Airflow Variable config
dag_config = Variable.get("finance_config", deserialize_json=True)


default_args = {
    'owner': 'aws-datalake',
    'depends_on_past': False,
    'retries': int(dag_config.get("retry_count", 3)),
    'start_date': datetime.today() - timedelta(days=1),
    'retry_delay': timedelta(minutes=int(dag_config.get("retry_delay_minutes", 5)))
}

dag = DAG(
    'aws_datalake_finance',
    default_args=default_args,
    description='Dag que inicia syncs airbyte',
    tags=['airbyte', 'glue'],
    schedule_interval=dag_config.get("schedule"),
    max_active_runs=int(dag_config.get("dag_max_active_runs", 1)),
    concurrency=int(dag_config.get("tasks_concurrency", 5)),
    catchup=False
)

start_dag = DummyOperator(task_id="start_dag", dag=dag)
finish_dag = DummyOperator(task_id="finish_dag",dag=dag)


glue_job_trusted = dag_config.get("glue_job_trusted")
glue_job_refined = dag_config.get("glue_job_refined")
glue_asset_bucket = dag_config.get("glue_asset_bucket")

run_glue_job_trusted = GlueJobOperator(
    task_id=f'run_{glue_job_trusted}',
    job_name=glue_job_trusted,
    iam_role_name="GlueJobRole",
    script_location=f"s3://{glue_asset_bucket}/scripts/raw_to_trusted.py",
    script_args=getGlueJobArguments(glue_job_trusted, glue_asset_bucket),
    num_of_dpus=2,
    create_job_kwargs = {"GlueVersion":"3.0"},
    run_job_kwargs = {"ExecutionClass":"STANDARD", "NumberOfWorkers":2, "WorkerType":"G.1X"},
    dag=dag
)

run_glue_job_refined = GlueJobOperator(
    task_id=f'run_{glue_job_refined}',
    job_name=glue_job_refined,
    iam_role_name="GlueJobRole",
    script_location=f"s3://{glue_asset_bucket}/scripts/trusted_to_refined.py",
    script_args=getGlueJobArguments(glue_job_refined, glue_asset_bucket),
    num_of_dpus=2,
    create_job_kwargs = {"GlueVersion":"3.0"},
    run_job_kwargs = {"ExecutionClass":"STANDARD", "NumberOfWorkers":2, "WorkerType":"G.1X"},
    dag=dag
)


for airbyte_con in dag_config.get("connections"):
    sync_source_destination = CogAirbyteTriggerSyncOperator(
        task_id=f'airbyte_sync_{airbyte_con}',
        airbyte_connection_name=airbyte_con,
        airflow_connection="airbyte_default",
        dag=dag
    )

    start_dag >> sync_source_destination >> run_glue_job_trusted >> run_glue_job_refined >> finish_dag
